using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Trabalho.Models;
using Trabalho.Repository;
using Newtonsoft.Json;

namespace Trabalho.Controllers;

public class AdmController : Controller
{
    private readonly IadmRepository _admRepository;
    public AdmController(IadmRepository admRepository)
    {
        _admRepository = admRepository;
    }
    public IActionResult Index()

    {
        string sessaoadm = HttpContext.Session.GetString("sessaoadmlogado");
        if (string.IsNullOrEmpty(sessaoadm))
        {
            return RedirectToAction("Index", "Login");

        }
        Adm adm = JsonConvert.DeserializeObject<Adm>(sessaoadm);

        return View(adm);
    }

    public IActionResult Cadastro()
    {
        return View();
    }
    public IActionResult Inicio()
    {
        return View();
    }



    [HttpPost]
    public IActionResult Cadastro(Adm adm)
    {
        _admRepository.Adicionar(adm);
        return RedirectToAction("Index", "Adm");
    }
    public IActionResult Deletar()
    {
        string sessaoadm = HttpContext.Session.GetString("sessaoadmlogado");
        Adm adm2 = JsonConvert.DeserializeObject<Adm>(sessaoadm);
        _admRepository.Deletar(adm2);
        return RedirectToAction("Index", "Login");
    }


}