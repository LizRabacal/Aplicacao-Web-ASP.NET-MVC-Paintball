using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Trabalho.Models;
using Trabalho.Repository;

namespace Trabalho.Controllers
{
    public class LoginController : Controller
    {
        private readonly IadmRepository _admRepository;
        private readonly ISessao _sessao;
        public LoginController(IadmRepository admRepository, ISessao sessao)
        {
            _admRepository = admRepository;
            _sessao = sessao;

        }

        public IActionResult Index()
        {
            if (_sessao.BuscarSessao() != null) return RedirectToAction("Index", "Adm");

            return View("Index");
        }
        public IActionResult Sair()
        {
            _sessao.RemoverSessao();

            return RedirectToAction("Index", "Login");

        }

        [HttpPost]
        public IActionResult Login(LoginModel login)
        {

            try
            {
                if (ModelState.IsValid)
                {


                    Adm usuariovalido = _admRepository.buscarporemail(login.email);

                    if (usuariovalido != null)
                    {
                        if (usuariovalido.senhavalida(login.senha))
                        {
                             ViewData["LoginErrado"] = "";

                            _sessao.CriarSessaodoAdm(usuariovalido);
                       
                            return RedirectToAction("Index", "Adm");
                        }else{
                             ViewData["LoginErrado"] = "Email e/ou senha errados";
                        }
                    }else{
                         ViewData["LoginErrado"] = "Email e/ou senha errados";
                    }

               
                }
                else
                {


                    return RedirectToAction("Index", "Login");
                }

                return View("Index", login);
            }
            catch (Exception erro)
            {
                return View();
            }
        }


    }
}