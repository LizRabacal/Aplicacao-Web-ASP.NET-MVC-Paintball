using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Trabalho.Models;
using Trabalho.Repository;

namespace Trabalho.Controllers
{
    public class ClienteController : Controller
    {

        private readonly IclienteRepository _repositorio;
        public ClienteController(IclienteRepository repositorio)
        {
            _repositorio = repositorio;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Cadastro()
        {
            return View();
        }
        public IActionResult Editar(int Id)
        {

            ClienteModel cliente = _repositorio.existe(Id);

            if (cliente != null)
            {
                return View(cliente);
            }
            else
            {
                return RedirectToAction("Listar", "Cliente");
            }

        }

        public IActionResult Listar()
        {
            List<ClienteModel> clientes = _repositorio.ListarClientes();
            return View(clientes);
        }
        public IActionResult Remover(int Id)
        {
              ClienteModel cliente = _repositorio.existe(Id);

            if (cliente != null)
            {
                _repositorio.Remover(cliente);
                return RedirectToAction("Listar", "Cliente");
            }
            else
            {
                return RedirectToAction("Listar", "Cliente");
            }
        }


        [HttpPost]

        public IActionResult Cadastro(ClienteModel clienteModel)
        {
            _repositorio.Cadastrar(clienteModel);
            return RedirectToAction("Index", "Adm"); ;
        }
        [HttpPost]
        public IActionResult Editar(ClienteModel clienteatualizado)
        {
            _repositorio.Editar(clienteatualizado);

            return RedirectToAction("Listar", "Cliente");
        }
       





    }
}